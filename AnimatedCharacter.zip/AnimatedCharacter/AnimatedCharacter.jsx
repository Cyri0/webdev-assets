import React, {useEffect, useState} from 'react'


const AnimatedCharacter = (props) => {
    const [actualStep, setActualStep] = useState(0)

    let characterStyle = {
        width: `${props.size}px`,
        height: `${props.size}px`,
        backgroundImage: `url(${props.image})`,
        backgroundSize: `${props.charactersPerLine * 100}%`,
        imageRendering: "pixelated",
        backgroundPosition: `${props.steps[actualStep]*props.size}px ${props.characterId*props.size}px`
    }

    useEffect(() => {
        const interval = setInterval(() => {
            setActualStep(actualStep => {return actualStep + 1 < props.steps.length? actualStep + 1 : 0})
        }, 1000 / props.fps);

        return () => clearInterval(interval)
    }, [actualStep, setActualStep])
    
    return (
    <div style={characterStyle}>
    </div>
  )
}

import characters from './characters.png'

AnimatedCharacter.defaultProps = {
    characterId: 0,
    frame: 0,
    steps: [5,6],
    fps: 5,
    size: 200,
    image: characters,
    charactersPerLine: 10
}

export default AnimatedCharacter